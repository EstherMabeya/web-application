const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const session = require("express-session");
const bodyParser = require("body-parser");

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(session({
  secret: "secret_key",
  resave: false,
  saveUninitialized: true
}));

// DB Connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "user_app"
});

db.connect(err => {
  if (err) throw err;
  console.log("MySQL connected!");
});

// Routes
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

app.post("/register", async (req, res) => {
  const { username, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  db.query("INSERT INTO users (username, password) VALUES (?, ?)", [username, hash], (err) => {
    if (err) return res.send("Error: " + err.message);
    res.redirect("/");
  });
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  db.query("SELECT * FROM users WHERE username = ?", [username], async (err, results) => {
    if (results.length > 0 && await bcrypt.compare(password, results[0].password)) {
      req.session.userId = results[0].id;
      res.redirect("/form.html");
    } else {
      res.send("Invalid credentials");
    }
  });
});

app.post("/submit", (req, res) => {
  if (!req.session.userId) return res.redirect("/");
  const { content } = req.body;
  db.query("INSERT INTO submissions (user_id, content) VALUES (?, ?)", [req.session.userId, content], (err) => {
    if (err) return res.send("Submission failed");
    res.send("Form submitted!");
  });
});

app.listen(port, () => console.log(`Server running at http://localhost:${port}`));
